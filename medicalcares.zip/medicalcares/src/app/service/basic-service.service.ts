import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BasicServiceService {
private token : string = "";
springURL: string = environment.baseUrl;

  constructor(private http: HttpClient) { }

  getToken(): string {
    return this.token;
  }
  setToken(token: string) {
    this.token = token;
  }

  login(username: string, password: string): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + btoa(username + ":" + password));
    console.log(headers);
    return this.http.get(this.springURL + "/authentication", { headers }); 
    
  }
}
