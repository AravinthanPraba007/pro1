import { Injectable } from '@angular/core';
import { Doctor } from '../Bean/Doctor';
import { Subject, Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { BasicServiceService } from './basic-service.service';

@Injectable({
  providedIn: 'root'
})
export class PatientServiceService {
  private subject = new Subject<Doctor[]>();
  springURL: string = environment.baseUrl;


  constructor(private http: HttpClient, private basicService : BasicServiceService) { }

  getSubject(): Subject<Doctor[]> {
    return this.subject;
  }


  getDoctorDetailes(): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicService.getToken());
    return this.http.get<Doctor[]>(this.springURL + "/user/doctordetails", { headers });
  }
}
