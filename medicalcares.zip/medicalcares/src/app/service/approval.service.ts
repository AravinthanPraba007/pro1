import { Injectable } from '@angular/core';

import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BasicServiceService } from './basic-service.service';
import { environment } from 'src/environments/environment';
import { User } from '../Bean/User';

@Injectable({
  providedIn: 'root'
})
export class ApprovalService {

springURL = environment.baseUrl;

  constructor(private basicServiceService :BasicServiceService, private http: HttpClient) { }

  getUnapprovedDoctors(): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicServiceService.getToken());
    console.log(headers);
    return this.http.get(this.springURL+ "/user/doctorapproverequest", { headers });
  }
  

  OnApp(user : User) {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicServiceService.getToken());
    console.log(headers);
    return this.http.put(this.springURL+ "/user/admindoctorupdate", user , { headers });
  }

  onReject(id: number) {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicServiceService.getToken());
    return this.http.delete(this.springURL + "/user/" +id , { headers });
  }



  getUnapprovedPatient(): Observable<any> {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicServiceService.getToken());
    console.log(headers);
    return this.http.get(this.springURL+ "/user/patientapproverequest", { headers });
  }
  

  OnAppPatient(user : User) {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicServiceService.getToken());
    console.log(headers);
    return this.http.put(this.springURL+ "/user/adminpatientupdate", user , { headers });
  }

  onRejectPatient(id: number) {
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Bearer ' + this.basicServiceService.getToken());
    return this.http.delete(this.springURL + "/user/patient/" +id , { headers });
  }


}
