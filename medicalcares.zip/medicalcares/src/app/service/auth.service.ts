import { Injectable } from '@angular/core';
import { BasicServiceService } from './basic-service.service';
import { User } from '../Bean/User';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
loggedinUser : boolean =false;
validUser: boolean = true;
userRole: string;


  constructor(private basicService : BasicServiceService, private router : Router) { }

  authenticateUser(user : any){
    this.basicService.login(user.username, user.password).subscribe(
(data)=>{
    console.log(data);
    this.loggedinUser=true;
    this.validUser=true;
    this.basicService.setToken(data.token);
    this.userRole = data.role;
    console.log(this.userRole);
    if(this.userRole=="admin"){
      this.router.navigate(['admin']);
    }
    else if(this.userRole=="doctor"){
      this.router.navigate(['doctor']);
    }
    else if(this.userRole=="patient") {
      this.router.navigate(['patient']);
    }

},

(error) => {
  this.validUser = false;
}

    )
  }

  logOut() {
   // if (this.userRole == "admin") {
     // this.movieService.isAdmin = false;
    //  this.isAdmin = false;
    
    this.basicService.setToken(null);
    this.loggedinUser = false;
   // this.movieService.loggedInUser = this.loggedInUser;
   // this.movieService.clickedAdd = false;
    this.router.navigate(["/login"]);
  }
}
