import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-signup',
  templateUrl: './doctor-signup.component.html',
  styleUrls: ['./doctor-signup.component.css']
})
export class DoctorSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
