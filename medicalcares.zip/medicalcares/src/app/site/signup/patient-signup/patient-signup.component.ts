import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-signup',
  templateUrl: './patient-signup.component.html',
  styleUrls: ['./patient-signup.component.css']
})
export class PatientSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
