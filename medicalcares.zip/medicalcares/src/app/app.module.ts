import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';

import { LoginComponent } from './site/login/login.component';
import { AdminHomeComponent } from './Admin/admin-home/admin-home.component';
import { DoctorHomeComponent } from './Doctor/doctor-home/doctor-home.component';
import { PatientHomeComponent } from './Patient/patient-home/patient-home.component';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { DoctorSignupComponent } from './site/signup/doctor-signup/doctor-signup.component';
import { PatientSignupComponent } from './site/signup/patient-signup/patient-signup.component';
import { DoctoracceptComponent } from './Admin/doctoraccept/doctoraccept.component';
import { PatientacceptComponent } from './Admin/patientaccept/patientaccept.component';
import { BookingComponent } from './Patient/booking/booking.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminHomeComponent,
    DoctorHomeComponent,
    PatientHomeComponent,
    DoctorSignupComponent,
    PatientSignupComponent,
    DoctoracceptComponent,
    PatientacceptComponent,
    BookingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
