import { Component, OnInit } from '@angular/core';
import { Doctor } from 'src/app/Bean/Doctor';
import { PatientServiceService } from 'src/app/service/patient-service.service';

@Component({
  selector: 'app-patient-home',
  templateUrl: './patient-home.component.html',
  styleUrls: ['./patient-home.component.css']
})
export class PatientHomeComponent implements OnInit {
doctorList : Doctor[];
filtereddoctorList : Doctor[];
searchKey: string;

  constructor(private patienrtService:PatientServiceService) { }

  ngOnInit() {
     this.patienrtService.getDoctorDetailes().subscribe(
   data => {
     this.doctorList= data;
     console.log(this.doctorList.mediList.medicareservice);
     this.filtereddoctorList = this.doctorList;
   }
);

  }
search(){
  this.filtereddoctorList= this.doctorList.filter(item => item.specality.toLocaleLowerCase().includes(this.searchKey.toLocaleLowerCase()));
  this.patienrtService.getSubject().next(this.filtereddoctorList);
}


}
