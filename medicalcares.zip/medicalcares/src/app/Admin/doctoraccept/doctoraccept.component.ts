import { Component, OnInit } from '@angular/core';
import { ApprovalService } from 'src/app/service/approval.service';
import { User } from 'src/app/Bean/User';

@Component({
  selector: 'app-doctoraccept',
  templateUrl: './doctoraccept.component.html',
  styleUrls: ['./doctoraccept.component.css']
})
export class DoctoracceptComponent implements OnInit {
  user : User[];
  size:number;
  constructor(private approvalService : ApprovalService) { }

  ngOnInit() {
    this.getData();
    
  }

  onApprove(user : User){
   
      this.approvalService.OnApp(user).subscribe(
        (data) =>{
          this.getData();
        }
      );
      
    
  }
  

  onReject(id:number){
  
      this.approvalService.onReject(id).subscribe(
        (data) => {
          this.getData();
        }
      )
    

  }


  getData() {
    this.approvalService.getUnapprovedDoctors().subscribe(
      (data: User[]) => {
        this.user = data;
        this.size=this.user.length;
      }
    )
  }

}
