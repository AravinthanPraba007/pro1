import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { PatientHomeComponent } from './Patient/patient-home/patient-home.component';
import { DoctorHomeComponent } from './Doctor/doctor-home/doctor-home.component';
import { AdminHomeComponent } from './Admin/admin-home/admin-home.component';
import { PatientacceptComponent } from './Admin/patientaccept/patientaccept.component';
import { DoctoracceptComponent } from './Admin/doctoraccept/doctoraccept.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
{ path: 'admin', component: AdminHomeComponent },
{ path: 'doctor', component: DoctorHomeComponent },
{ path: 'patient', component: PatientHomeComponent },
{ path: 'doctoraccept', component: DoctoracceptComponent },
{ path: 'patientaccept', component: PatientacceptComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
